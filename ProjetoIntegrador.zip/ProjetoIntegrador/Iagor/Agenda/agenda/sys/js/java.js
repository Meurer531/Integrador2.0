function contato() {
    var div = document.getElementsById("tabelaCont");
    if (div.style.display == "block")
    {
    div.style.display = "none";
    }
    else{
    div.style.display = "block";
    }
}

