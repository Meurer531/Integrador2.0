<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

    </head>
    <body>
        <form method="post" action="dashboard.php" enctype="multipart/form-data">
            <div class="fundo">
                
            </div>
        </form>
    </body>
</html>